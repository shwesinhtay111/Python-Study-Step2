# Create 2+3j
print(complex(2,3))

print(complex(10,1))

print(complex('12+2j'))