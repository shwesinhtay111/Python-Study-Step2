lst = [True,True,False,True]
print(all(lst))
print(any(lst))